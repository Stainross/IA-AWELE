module ia_project {
	exports awele.bot.demo.minmax;
	exports awele.bot.demo.first;
	exports awele.bot.demo.last;
	exports awele.core;
	exports awele.data;
	exports awele.bot;
	exports awele.run;
	exports awele.bot.demo.random;
	exports awele.output;
	exports awele.bot.demo.knn1;
	exports awele.bot.demo.knn2;

	requires java.desktop;
	requires javassist;
	requires reflections;
}