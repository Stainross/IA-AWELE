package awele.bot;

/**
 * @author Alexandre Blansché
 * Uniquement pour les Bot en exemple.
 * Ce n'est pas la classe à étendre pour le projet, c'est la classe CompetitorBot qu'il faut étendre !
 */
public abstract class DemoBot extends Bot
{
}
