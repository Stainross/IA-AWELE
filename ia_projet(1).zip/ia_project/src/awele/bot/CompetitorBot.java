package awele.bot;

/**
 * @author Alexandre Blansché
 * Classe abstraite représentant un joueur artificiel pour l'Awele
 * C'est la classe à étendre pour le projet !
 */
public abstract class CompetitorBot extends Bot
{
}
